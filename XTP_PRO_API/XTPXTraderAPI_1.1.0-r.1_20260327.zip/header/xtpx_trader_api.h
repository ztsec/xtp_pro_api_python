/////////////////////////////////////////////////////////////////////////
///@author 中泰证券股份有限公司
///@file xtpx_trader_api.h
///@brief 定义客户端交易接口
/////////////////////////////////////////////////////////////////////////

#ifndef _XTPX_TRADER_API_H_
#define _XTPX_TRADER_API_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "xtpx_api_data_type.h"
#include "xtpx_api_struct_common.h"
#include "xoms_x_api_struct.h"
#include "xgw_x_api_fund_struct.h"
#include "xgw_x_api_query_struct.h"

#if defined(ISLIB) && defined(WIN32)
#ifdef LIB_XTPX_TRADER_API_EXPORT
#define XTPX_TRADER_API_EXPORT __declspec(dllexport)
#else
#define XTPX_TRADER_API_EXPORT __declspec(dllimport)
#endif
#else
#define XTPX_TRADER_API_EXPORT 
#endif

/*!
* \class XTPX::API::TraderSpi
*
* \brief 交易接口响应类
*
* \author 中泰证券股份有限公司
* \date 三月 2025
*/
namespace XTPX {
	namespace API {

		class TraderSpi
		{
		public:

			///当客户端的某个连接与交易后台通信连接断开时，该方法被调用。
			///@param reason 错误原因，请与错误代码表对应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 用户主动调用logout导致的断线，不会触发此函数。api不会自动重连，当断线发生时，请用户自行选择后续操作，可以在此函数中调用Login重新登录，并更新session_id，此时用户收到的数据跟断线之前是连续的
			virtual void OnDisconnected(uint64_t session_id, int reason) { (void)session_id; (void)reason; };

			///当登录成功后，中途出现某个服务（资金划拨或者查询）服务状态改变时，该方法将被调用。
			///@param session_id 资金账户对应的session_id，登录时得到
			///@param server_type 服务类型，1-资金划拨服务，2-查询服务
			///@param status 服务是否可用标识，false-服务不可用，true-服务恢复可用
			///@remark 用户登录成功时，默认查询服务可用，资金划拨服务是否可用得等待此回调函数通知。当用户收到服务不可用的通知时，之前没有完成的查询，将不再推送后续的查询消息，需要用户等待查询服务恢复后重新发起查询。
			virtual void OnServerStatusNotification(uint64_t session_id, uint32_t server_type, bool status) { (void)session_id; (void)server_type; (void)status; };

			///错误应答
			///@param error_info 当服务器响应发生错误时的具体的错误代码和错误信息,当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@remark 此函数只有在服务器发生错误时才会调用，一般无需用户处理
			virtual void OnError(XTPRI *error_info) { (void)error_info; };


			///当客户认证成功时，该方法被调用。		
			///@param session_id 资金账户对应的session_id，登录时得到
			///@param user_name 登录用户名，login时传入的
			///@remark 用户收到此回调，仅表明已经认证成功，此时还不能向服务器发送报单和查询等操作，需要等login返回才能进行后续下单操作，此处可提前记录并更新用户名与session_id的对应关系
			virtual void OnConnect(uint64_t session_id, const char* user_name) { (void)session_id; (void)user_name; };

			///断线重连后，所有需要重传的推送消息（成交回报、订单响应）接收结束通知
			///@param session_id 账户对应的session_id，登录时得到
			///@remark 此函数在用户使用quick第一次登录时，不会有触发。只有在API与服务器以restart方式登录时，或者api与服务器非主动断线，且用户重新login后，进行resume消息重传时，当推送消息重传结束时才会调用，收到此通知就表明断线时的推送消息已经接受完毕，后面收到的推送消息将是实时推送消息
			virtual void OnResumeEnd(uint64_t session_id) { (void)session_id; };

			///报单未知状态通知
			///@param order_xtp_id 未知状态订单的xtp id
			///@param session_id 账户对应的session_id，登录时得到
			///@remark 此响应仅表明XTP服务器丢失订单，并没有报送到交易所。
			virtual void OnUnknownOrder(uint64_t order_xtp_id, uint64_t session_id) { (void)order_xtp_id; (void)session_id; };

			///报单初始状态通知
			///@param order_info 订单响应具体信息，用户可以通过order_info.order_xtp_id来管理订单，通过GetClientIDByXTPID() == client_id来过滤自己的订单
			///@param session_id 账户对应的session_id，登录时得到
			///@remark 此响应仅表明XTP服务器收到了报单且没被OMS拒单（OMS内部拒单将没有这条ack消息，仅有OrderEvent的拒单消息），不代表已经报送到交易所
			virtual void OnOrderAck(XTPOrderInfo *order_info, uint64_t session_id) { (void)order_info; (void)session_id; };

// 			///请求查询用户在本节点上可交易市场的响应
// 			///@param trade_location 查询到的交易市场信息，按位来看，从低位开始数，第0位表示沪市，即如果(trade_location&0x01) == 0x01，代表可交易沪市，第1位表示深市，即如果(trade_location&0x02) == 0x02，表示可交易深市，如果第0位和第1位均是1，即(trade_location&(0x01|0x02)) == 0x03，就表示可交易沪深2个市场
// 			///@param error_info 查询可交易市场发生错误时，返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 此查询只会有一个结果
// 			virtual void OnQueryAccountTradeMarket(int trade_location, XTPRI *error_info, int request_id, uint64_t session_id) {};

			///报单通知
			///@param order_info 订单响应具体信息，用户可以通过order_info.order_xtp_id来管理订单，通过GetClientIDByXTPID() == client_id来过滤自己的订单，order_info.qty_left字段在订单为未成交、部成、全成、废单状态时，表示此订单还没有成交的数量，在部撤、全撤状态时，表示此订单被撤的数量。order_info.order_cancel_xtp_id为其所对应的撤单ID，不为0时表示此单被撤成功
			///@param error_info 订单被拒绝或者发生错误时错误代码和错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 每次订单状态更新时，都会被调用，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线，在订单未成交、全部成交、全部撤单、部分撤单、已拒绝这些状态时会有响应，对于部分成交的情况，请由订单的成交回报来自行确认。所有登录了此用户的客户端都将收到此用户的订单响应
			virtual void OnOrderEvent(XTPOrderInfo *order_info, XTPRI *error_info, uint64_t session_id) { (void)order_info; (void)error_info; (void)session_id; };

			///成交通知
			///@param trade_info 成交回报的具体信息，用户可以通过trade_info.order_xtp_id来管理订单，通过GetClientIDByXTPID() == client_id来过滤自己的订单。对于上交所，exec_id可以唯一标识一笔成交。当发现2笔成交回报拥有相同的exec_id，则可以认为此笔交易自成交了。对于深交所，exec_id是唯一的，暂时无此判断机制。report_index+market字段可以组成唯一标识表示成交回报。
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 订单有成交发生的时候，会被调用，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。所有登录了此用户的客户端都将收到此用户的成交回报。相关订单为部成状态，需要用户通过成交回报的成交数量来确定，OnOrderEvent()不会推送部成状态。
			virtual void OnTradeEvent(XTPTradeReport *trade_info, uint64_t session_id) { (void)trade_info; (void)session_id; };

			///撤单出错响应
			///@param cancel_info 撤单具体信息，包括撤单的order_cancel_xtp_id和待撤单的order_xtp_id
			///@param error_info 撤单被拒绝或者发生错误时错误代码和错误信息，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 此响应只会在撤单发生错误时被回调
			virtual void OnCancelOrderError(XTPOrderCancelErrorInfo *cancel_info, XTPRI *error_info, uint64_t session_id) { (void)cancel_info; (void)error_info; (void)session_id; };

			///请求查询报单响应
			///@param order_info 查询到的一个报单
			///@param error_info 查询报单时发生错误时，返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 由于支持分时段查询，一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。此对应的请求函数不建议轮询使用，当报单量过多时，容易造成用户线路拥堵，导致api断线
			virtual void OnQueryOrder(XTPQueryOrderRsp *order_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)order_info; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

// 			///请求查询报单响应-新版本接口
// 			///@param order_info 查询到的一个报单信息
// 			///@param error_info 查询报单时发生错误时，返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 由于支持分时段查询，一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryOrderEx(XTPOrderInfoEx *order_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)order_info; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

			///分页请求查询报单响应
			///@param order_info 查询到的一个报单
			///@param req_count 分页请求的最大数量
			///@param order_sequence 分页请求的当前回报数量
			///@param query_reference 当前报单信息所对应的查询索引，需要记录下来，在进行下一次分页查询的时候需要用到
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 当order_sequence为0，表明当次查询没有查到任何记录，当is_last为true时，如果order_sequence等于req_count，那么表示还有报单，可以进行下一次分页查询，如果不等，表示所有报单已经查询完毕。一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。
			virtual void OnQueryOrderByPage(XTPQueryOrderRsp *order_info, int64_t req_count, int64_t order_sequence, int64_t query_reference, int request_id, bool is_last, uint64_t session_id) { (void)order_info; (void)req_count; (void)order_sequence; (void)query_reference; (void)request_id; (void)is_last; (void)session_id; };

// 			///分页请求查询报单响应
// 			///@param order_info 查询到的一个报单
// 			///@param req_count 分页请求的最大数量
// 			///@param order_sequence 分页请求的当前回报数量
// 			///@param query_reference 当前报单信息所对应的查询索引，需要记录下来，在进行下一次分页查询的时候需要用到
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 当order_sequence为0，表明当次查询没有查到任何记录，当is_last为true时，如果order_sequence等于req_count，那么表示还有报单，可以进行下一次分页查询，如果不等，表示所有报单已经查询完毕。一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。
// 			virtual void OnQueryOrderByPageEx(XTPOrderInfoEx *order_info, int64_t req_count, int64_t order_sequence, int64_t query_reference, int request_id, bool is_last, uint64_t session_id) { (void)order_info; (void)req_count; (void)order_sequence; (void)query_reference; (void)request_id; (void)is_last; (void)session_id; };

			///请求查询成交响应
			///@param trade_info 查询到的一个成交回报
			///@param error_info 查询成交回报发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 由于支持分时段查询，一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。此对应的请求函数不建议轮询使用，当报单量过多时，容易造成用户线路拥堵，导致api断线
			virtual void OnQueryTrade(XTPQueryTradeRsp *trade_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)trade_info; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

			///分页请求查询成交响应
			///@param trade_info 查询到的一个成交信息
			///@param req_count 分页请求的最大数量
			///@param trade_sequence 分页请求的当前回报数量
			///@param query_reference 当前报单信息所对应的查询索引，需要记录下来，在进行下一次分页查询的时候需要用到
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 当trade_sequence为0，表明当次查询没有查到任何记录，当is_last为true时，如果trade_sequence等于req_count，那么表示还有回报，可以进行下一次分页查询，如果不等，表示所有回报已经查询完毕。一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。
			virtual void OnQueryTradeByPage(XTPQueryTradeRsp *trade_info, int64_t req_count, int64_t trade_sequence, int64_t query_reference, int request_id, bool is_last, uint64_t session_id) { (void)trade_info; (void)req_count; (void)trade_sequence; (void)query_reference; (void)request_id; (void)is_last; (void)session_id; };

			///请求查询投资者持仓响应
			///@param position 查询到的一只股票的持仓情况
			///@param error_info 查询账户持仓发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 由于用户可能持有多个股票，一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			virtual void OnQueryPosition(XTPQueryStkPositionRsp *position, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)position; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

			///请求查询用户证券账户信息响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			///@param account_info 查询到的用户证券账户信息
			///@param error_info 查询用户证券账户信息发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			virtual void OnQuerySecurityAccount(XTPQueryAccountIdRsp *account_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)account_info; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

			///请求查询资金账户响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			///@param asset 查询到的资金账户情况
			///@param error_info 查询资金账户发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			virtual void OnQueryAsset(XTPQueryAssetRsp *asset, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)asset; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

			///请求查询资金划拨订单响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			///@param fund_transfer_info 查询到的资金账户情况
			///@param fund_transfer_err_info 返回的资金划拨订单fund_transfer_info划拨失败时的错误信息，当fund_transfer_err_info为空，或者fund_transfer_err_info.error_id为0时，表明划转成功，没有错误
			///@param error_info 查询资金划拨订单发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明查询没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			virtual void OnQueryFundTransfer(XTPFundTransferLog *fund_transfer_info, XTPRI *fund_transfer_err_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)fund_transfer_info; (void)fund_transfer_err_info; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

			///分页请求查询资金划拨订单响应
			///@param fund_transfer_info 查询到的一个资金划拨订单
			///@param fund_transfer_err_info 返回的资金划拨订单order_info划拨失败时的错误信息，当fund_transfer_err_info为空，或者fund_transfer_err_info.error_id为0时，表明划转成功，没有错误
			///@param error_info 分页查询资金资金划拨订单发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明查询没有错误
			///@param req_count 分页请求的最大数量
			///@param sequence 分页请求的当前回报数量
			///@param query_reference 当前资金划拨订单信息所对应的查询索引，需要记录下来，在进行下一次分页查询的时候需要用到
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 当order_sequence为0，表明当次查询没有查到任何记录，当is_last为true时，如果sequence等于req_count，那么表示还有报单，可以进行下一次分页查询，如果不等，表示所有报单已经查询完毕。一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。
			virtual void OnQueryFundTransferByPage(XTPFundTransferLog *fund_transfer_info, XTPRI *fund_transfer_err_info, XTPRI *error_info, int64_t req_count, int64_t sequence, int64_t query_reference, int request_id, bool is_last, uint64_t session_id) { (void)fund_transfer_info; (void)fund_transfer_err_info; (void)error_info; (void)req_count; (void)sequence; (void)query_reference; (void)request_id; (void)is_last; (void)session_id; };

			///资金划拨通知
			///@param fund_transfer_info 资金划拨通知的具体信息，用户可以通过fund_transfer_info.serial_id来管理订单，通过GetClientIDByXTPID() == client_id来过滤自己的订单。
			///@param error_info 资金划拨订单被拒绝或者发生错误时错误代码和错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误。当资金划拨方向为一号两中心节点之间划拨，且error_info.error_id=11000384时，error_info.error_msg中含有对方结点中可用于划拨的资金（以整数为准），用户需解析后进行stringToInt的转化，可据此填写合适的资金，再次发起划拨请求
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 当资金划拨订单有状态变化的时候，会被调用，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。所有登录了此用户的客户端都将收到此用户的资金划拨通知。
			virtual void OnFundTransfer(XTPFundTransferNotice *fund_transfer_info, XTPRI *error_info, uint64_t session_id) { (void)fund_transfer_info; (void)error_info; (void)session_id; };

			///资金划拨订单未知状态通知
			///@param serial_id 未知状态资金划拨订单的serial id
			///@param session_id 账户对应的session_id，登录时得到
			///@remark 此响应仅表明XTP资金划拨服务器丢失订单，并没有报送到后台。
			virtual void OnUnknownFundTransfer(uint64_t serial_id, uint64_t session_id) { (void)serial_id; (void)session_id; };

			///请求查询其他节点可用资金的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			///@param fund_info 查询到的其他节点可用资金情况
			///@param error_info 查询其他节点可用资金发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			virtual void OnQueryOtherServerFund(XTPFundQueryRsp *fund_info, XTPRI *error_info, int request_id, uint64_t session_id) { (void)fund_info; (void)error_info; (void)request_id; (void)session_id; };

			///请求查询ETF清单文件的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			///@param etf_info 查询到的ETF清单文件情况
			///@param error_info 查询ETF清单文件发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			virtual void OnQueryETF(XTPQueryETFBaseRsp *etf_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)etf_info; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

			///请求查询ETF股票篮的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			///@param etf_component_info 查询到的ETF合约的相关成分股信息
			///@param error_info 查询ETF股票篮发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			virtual void OnQueryETFBasket(XTPQueryETFComponentRsp *etf_component_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)etf_component_info; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

			///请求查询今日新股申购信息列表的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			///@param ipo_info 查询到的今日新股申购的一只股票信息
			///@param error_info 查询今日新股申购信息列表发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			virtual void OnQueryIPOInfoList(XTPQueryIPOTickerRsp *ipo_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)ipo_info; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

			///请求查询用户新股申购额度信息的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			///@param quota_info 查询到的用户某个市场的今日新股申购额度信息
			///@param error_info 查查询用户新股申购额度信息发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			virtual void OnQueryIPOQuotaInfo(XTPQueryIPOQuotaRsp *quota_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)quota_info; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

			///请求查询今日可转债申购信息列表的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			///@param ipo_info 查询到的今日可转债申购的一只可转债信息
			///@param error_info 查询今日可转债申购信息列表发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			virtual void OnQueryBondIPOInfoList(XTPQueryIPOTickerRsp *ipo_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)ipo_info; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

			///请求查询用户可转债转股信息的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			///@param swap_stock_info 查询到某条可转债转股信息
			///@param error_info 查查询可转债转股信息发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
			///@param request_id 此消息响应函数对应的请求ID
			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
			///@param session_id 资金账户对应的session_id，登录时得到
			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
			virtual void OnQueryBondSwapStockInfo(XTPQueryBondSwapStockRsp *swap_stock_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) { (void)swap_stock_info; (void)error_info; (void)request_id; (void)is_last; (void)session_id; };

// 			///请求查询期权合约的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			///@param option_info 查询到的期权合约情况
// 			///@param error_info 查询期权合约发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryOptionAuctionInfo(XTPQueryOptionAuctionInfoRsp *option_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///融资融券业务中现金直接还款的响应
// 			///@param cash_repay_info 现金直接还款通知的具体信息，用户可以通过cash_repay_info.xtp_id来管理订单，通过GetClientIDByXTPID() == client_id来过滤自己的订单。
// 			///@param error_info 现金还款发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnCreditCashRepay(XTPCrdCashRepayRsp *cash_repay_info, XTPRI *error_info, uint64_t session_id) {};
// 
// 			///融资融券业务中现金还息的响应
// 			///@param cash_repay_info 现金还息通知的具体信息，用户可以通过cash_repay_info.xtp_id来管理订单，通过GetClientIDByXTPID() == client_id来过滤自己的订单。
// 			///@param error_info 现金还息发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnCreditCashRepayDebtInterestFee(XTPCrdCashRepayDebtInterestFeeRsp *cash_repay_info, XTPRI *error_info, uint64_t session_id) {};
// 
// 			///请求查询融资融券业务中的现金直接还款报单的响应
// 			///@param cash_repay_info 查询到的某一笔现金直接还款通知的具体信息
// 			///@param error_info 查询现金直接报单发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryCreditCashRepayInfo(XTPCrdCashRepayInfo *cash_repay_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///请求查询信用账户额外信息的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			///@param fund_info 查询到的信用账户额外信息情况
// 			///@param error_info 查询信用账户额外信息发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryCreditFundInfo(XTPCrdFundInfo *fund_info, XTPRI *error_info, int request_id, uint64_t session_id) {};
// 
// 			///请求查询信用账户负债信息的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			///@param debt_info 查询到的信用账户合约负债情况
// 			///@param error_info 查询信用账户负债信息发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryCreditDebtInfo(XTPCrdDebtInfo *debt_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///请求查询信用账户指定证券负债未还信息响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			///@param debt_info 查询到的信用账户指定证券负债未还信息情况
// 			///@param error_info 查询信用账户指定证券负债未还信息发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryCreditTickerDebtInfo(XTPCrdDebtStockInfo *debt_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///请求查询信用账户待还资金的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			///@param remain_amount 查询到的信用账户待还资金
// 			///@param error_info 查询信用账户待还资金发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryCreditAssetDebtInfo(double remain_amount, XTPRI *error_info, int request_id, uint64_t session_id) {};
// 
// 			///请求查询信用账户可融券头寸信息的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			///@param assign_info 查询到的信用账户可融券头寸信息
// 			///@param error_info 查询信用账户可融券头寸信息发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryCreditTickerAssignInfo(XTPClientQueryCrdPositionStkInfo *assign_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///融资融券业务中请求查询指定余券信息的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			///@param stock_info 查询到的余券信息
// 			///@param error_info 查询信用账户余券信息发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryCreditExcessStock(XTPClientQueryCrdSurplusStkRspInfo* stock_info, XTPRI *error_info, int request_id, uint64_t session_id) {};
// 
// 			///融资融券业务中请求查询余券信息的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			///@param stock_info 查询到的余券信息
// 			///@param error_info 查询信用账户余券信息发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryMulCreditExcessStock(XTPClientQueryCrdSurplusStkRspInfo* stock_info, XTPRI *error_info, int request_id, uint64_t session_id, bool is_last) {};
// 
// 			///融资融券业务中负债合约展期的通知
// 			///@param debt_extend_info 负债合约展期通知的具体信息，用户可以通过debt_extend_info.xtpid来管理订单，通过GetClientIDByXTPID() == client_id来过滤自己的订单。
// 			///@param error_info 负债合约展期订单被拒绝或者发生错误时错误代码和错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误。
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 当负债合约展期订单有状态变化的时候，会被调用，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。所有登录了此用户的客户端都将收到此用户的负债合约展期通知。
// 			virtual void OnCreditExtendDebtDate(XTPCreditDebtExtendNotice *debt_extend_info, XTPRI *error_info, uint64_t session_id) {};
// 
// 			///查询融资融券业务中负债合约展期订单响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			///@param debt_extend_info 查询到的负债合约展期情况
// 			///@param error_info 查询负债合约展期发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误。当error_info.error_id=11000350时，表明没有记录，当为其他非0值时，表明合约发生拒单时的错误原因
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryCreditExtendDebtDateOrders(XTPCreditDebtExtendNotice *debt_extend_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///查询融资融券业务中信用账户附加信息的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			///@param fund_info 信用账户附加信息
// 			///@param error_info 查询信用账户附加信息发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryCreditFundExtraInfo(XTPCrdFundExtraInfo *fund_info, XTPRI *error_info, int request_id, uint64_t session_id) {};
// 
// 			///查询融资融券业务中信用账户指定证券的附加信息的响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			///@param fund_info 信用账户指定证券的附加信息
// 			///@param error_info 查询信用账户附加信息发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryCreditPositionExtraInfo(XTPCrdPositionExtraInfo *fund_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///期权组合策略报单通知
// 			///@param order_info 订单响应具体信息，用户可以通过order_info.order_xtp_id来管理订单，通过GetClientIDByXTPID() == client_id来过滤自己的订单，order_info.qty_left字段在订单为未成交、部成、全成、废单状态时，表示此订单还没有成交的数量，在部撤、全撤状态时，表示此订单被撤的数量。order_info.order_cancel_xtp_id为其所对应的撤单ID，不为0时表示此单被撤成功
// 			///@param error_info 订单被拒绝或者发生错误时错误代码和错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 每次订单状态更新时，都会被调用，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线，在订单未成交、全部成交、全部撤单、部分撤单、已拒绝这些状态时会有响应，对于部分成交的情况，请由订单的成交回报来自行确认。所有登录了此用户的客户端都将收到此用户的订单响应
// 			virtual void OnOptionCombinedOrderEvent(XTPOptCombOrderInfo *order_info, XTPRI *error_info, uint64_t session_id) {};
// 
// 			///期权组合策略成交通知
// 			///@param trade_info 成交回报的具体信息，用户可以通过trade_info.order_xtp_id来管理订单，通过GetClientIDByXTPID() == client_id来过滤自己的订单。对于上交所，exec_id可以唯一标识一笔成交。当发现2笔成交回报拥有相同的exec_id，则可以认为此笔交易自成交了。对于深交所，exec_id是唯一的，暂时无此判断机制。report_index+market字段可以组成唯一标识表示成交回报。
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 订单有成交发生的时候，会被调用，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。所有登录了此用户的客户端都将收到此用户的成交回报。相关订单为部成状态，需要用户通过成交回报的成交数量来确定，OnOrderEvent()不会推送部成状态。
// 			virtual void OnOptionCombinedTradeEvent(XTPOptCombTradeReport *trade_info, uint64_t session_id) {};
// 
// 			///期权组合策略撤单出错响应
// 			///@param cancel_info 撤单具体信息，包括撤单的order_cancel_xtp_id和待撤单的order_xtp_id
// 			///@param error_info 撤单被拒绝或者发生错误时错误代码和错误信息，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 此响应只会在撤单发生错误时被回调
// 			virtual void OnCancelOptionCombinedOrderError(XTPOptCombOrderCancelInfo *cancel_info, XTPRI *error_info, uint64_t session_id) {};
// 
// 			///请求查询期权组合策略报单响应-旧版本接口
// 			///@param order_info 查询到的一个报单
// 			///@param error_info 查询报单时发生错误时，返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 由于支持分时段查询，一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。此对应的请求函数不建议轮询使用，当报单量过多时，容易造成用户线路拥堵，导致api断线
// 			virtual void OnQueryOptionCombinedOrders(XTPQueryOptCombOrderRsp *order_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///请求查询期权组合策略报单响应-新版本接口
// 			///@param order_info 查询到的一个报单
// 			///@param error_info 查询报单时发生错误时，返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 由于支持分时段查询，一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。此对应的请求函数不建议轮询使用，当报单量过多时，容易造成用户线路拥堵，导致api断线
// 			virtual void OnQueryOptionCombinedOrdersEx(XTPOptCombOrderInfoEx *order_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///分页请求查询期权组合策略报单响应-旧版本接口
// 			///@param order_info 查询到的一个报单
// 			///@param req_count 分页请求的最大数量
// 			///@param order_sequence 分页请求的当前回报数量
// 			///@param query_reference 当前报单信息所对应的查询索引，需要记录下来，在进行下一次分页查询的时候需要用到
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 当order_sequence为0，表明当次查询没有查到任何记录，当is_last为true时，如果order_sequence等于req_count，那么表示还有报单，可以进行下一次分页查询，如果不等，表示所有报单已经查询完毕。一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。
// 			virtual void OnQueryOptionCombinedOrdersByPage(XTPQueryOptCombOrderRsp *order_info, int64_t req_count, int64_t order_sequence, int64_t query_reference, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///分页请求查询期权组合策略报单响应-新版本接口
// 			///@param order_info 查询到的一个报单
// 			///@param req_count 分页请求的最大数量
// 			///@param order_sequence 分页请求的当前回报数量
// 			///@param query_reference 当前报单信息所对应的查询索引，需要记录下来，在进行下一次分页查询的时候需要用到
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 当order_sequence为0，表明当次查询没有查到任何记录，当is_last为true时，如果order_sequence等于req_count，那么表示还有报单，可以进行下一次分页查询，如果不等，表示所有报单已经查询完毕。一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。
// 			virtual void OnQueryOptionCombinedOrdersByPageEx(XTPOptCombOrderInfoEx *order_info, int64_t req_count, int64_t order_sequence, int64_t query_reference, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///请求查询期权组合策略成交响应
// 			///@param trade_info 查询到的一个成交回报
// 			///@param error_info 查询成交回报发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 由于支持分时段查询，一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。此对应的请求函数不建议轮询使用，当报单量过多时，容易造成用户线路拥堵，导致api断线
// 			virtual void OnQueryOptionCombinedTrades(XTPQueryOptCombTradeRsp *trade_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///分页请求查询期权组合策略成交响应
// 			///@param trade_info 查询到的一个成交信息
// 			///@param req_count 分页请求的最大数量
// 			///@param trade_sequence 分页请求的当前回报数量
// 			///@param query_reference 当前报单信息所对应的查询索引，需要记录下来，在进行下一次分页查询的时候需要用到
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 当trade_sequence为0，表明当次查询没有查到任何记录，当is_last为true时，如果trade_sequence等于req_count，那么表示还有回报，可以进行下一次分页查询，如果不等，表示所有回报已经查询完毕。一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。
// 			virtual void OnQueryOptionCombinedTradesByPage(XTPQueryOptCombTradeRsp *trade_info, int64_t req_count, int64_t trade_sequence, int64_t query_reference, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///请求查询期权组合策略持仓响应
// 			///@param position_info 查询到的一个持仓信息
// 			///@param error_info 查询持仓发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。
// 			virtual void OnQueryOptionCombinedPosition(XTPQueryOptCombPositionRsp *position_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///请求查询期权组合策略信息响应
// 			///@param strategy_info 查询到的一个组合策略信息
// 			///@param error_info 查询成交回报发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。
// 			virtual void OnQueryOptionCombinedStrategyInfo(XTPQueryCombineStrategyInfoRsp *strategy_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///查询期权行权合并头寸的响应
// 			///@param position_info 查询到的一个行权合并头寸信息
// 			///@param error_info 查询持仓发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 一个查询请求可能对应多个响应，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线。
// 			virtual void OnQueryOptionCombinedExecPosition(XTPQueryOptCombExecPosRsp *position_info, XTPRI *error_info, int request_id, bool is_last, uint64_t session_id) {};
// 
// 			///algo业务中查询策略列表的响应
// 			///@param strategy_info 策略具体信息
// 			///@param strategy_param 此策略中包含的参数，如果error_info.error_id为0时，有意义
// 			///@param error_info 查询查询策略列表发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnQueryStrategy(XTPStrategyInfoStruct* strategy_info, char* strategy_param, XTPRI *error_info, int32_t request_id, bool is_last, uint64_t session_id) {};
// 
// 			///algo业务中策略运行时策略状态通知
// 			///@param strategy_state 用户策略运行情况的状态通知
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnStrategyStateReport(XTPStrategyStateReportStruct* strategy_state, uint64_t session_id) {};
// 
// 			///algo业务中用户建立算法通道的消息响应
// 			///@param user 用户名
// 			///@param error_info 建立算法通道发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误，即算法通道成功
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 算法通道建立成功后，才能对用户创建策略等操作，一个用户只能拥有一个算法通道，如果之前已经建立，则无需重复建立
// 			virtual void OnALGOUserEstablishChannel(char* user, XTPRI* error_info, uint64_t session_id) {};
// 
// 			///algo业务中报送策略单的响应
// 			///@param strategy_info 用户报送的策略单的具体信息
// 			///@param error_info 报送策略单发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnInsertAlgoOrder(XTPStrategyInfoStruct* strategy_info, XTPRI *error_info, uint64_t session_id) {};
// 
// 			///algo业务中撤销策略单的响应
// 			///@param strategy_info 用户撤销的策略单的具体信息
// 			///@param error_info 撤销策略单发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnCancelAlgoOrder(XTPStrategyInfoStruct* strategy_info, XTPRI *error_info, uint64_t session_id) {};
// 
// 			///当客户端与AlgoBus通信连接断开时，该方法被调用。
// 			///@param reason 错误原因，请与错误代码表对应
// 			///@remark 请不要堵塞此线程，否则会影响algo的登录，与Algo之间的连接，断线后会自动重连，用户无需做其他操作
// 			virtual void OnAlgoDisconnected(int reason) {};
// 
// 			///当客户端与AlgoBus断线后重新连接时，该方法被调用，仅在断线重连成功后会被调用。
// 			virtual void OnAlgoConnected() {};
// 
// 			///algo业务中策略运行时策略指定证券执行状态通知
// 			///@param strategy_symbol_state 用户策略指定证券运行情况的状态通知
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnStrategySymbolStateReport(XTPStrategySymbolStateReport* strategy_symbol_state, uint64_t session_id) {};
// 
// 			///algo业务中报送母单创建时的推送消息(包括其他客户端创建的母单)
// 			///@param strategy_info 策略具体信息
// 			///@param strategy_param 此策略中包含的参数
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnNewStrategyCreateReport(XTPStrategyInfoStruct* strategy_info, char* strategy_param, uint64_t session_id) {};
// 
// 			///algo业务中算法推荐的响应
// 			///@param basket_flag 是否将满足条件的推荐结果打包成母单篮的标志，与请求一致，如果此参数为true，那么请以返回的strategy_param为准
// 			///@param recommendation_info 推荐算法的具体信息，当basket_flag=true时，此结构体中的market和ticker将没有意义，此时请以strategy_param为准
// 			///@param strategy_param 算法参数，可直接用来创建母单，如果error_info.error_id为0时，有意义
// 			///@param error_info 请求推荐算法发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param request_id 此消息响应函数对应的请求ID
// 			///@param is_last 此消息响应函数是否为request_id这条请求所对应的最后一个响应，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnStrategyRecommendation(bool basket_flag, XTPStrategyRecommendationInfo* recommendation_info, char* strategy_param, XTPRI *error_info, int32_t request_id, bool is_last, uint64_t session_id) {};
// 
// 			///algo业务中修改已有策略单的响应
// 			///@param strategy_info 用户修改后策略单的具体信息
// 			///@param error_info 修改策略单发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@remark 需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
// 			virtual void OnModifyAlgoOrder(XTPStrategyInfoStruct* strategy_info, XTPRI *error_info, uint64_t session_id) {};
		};
	}
}

#ifndef WINDOWS
#if __GNUC__ >= 4
#pragma GCC visibility push(default)
#endif
#endif

/*!
* \class XTPX::API::TraderApi
*
* \brief 交易接口类
*
* \author 中泰证券股份有限公司
* \date 三月 2025
*/
namespace XTPX {
	namespace API {

		class XTPX_TRADER_API_EXPORT TraderApi
		{
		public:
			///创建TraderApi
			///@param client_id （必须输入）客户端id，用于区分同一用户的不同客户端，由用户自定义，总体取值区间[1,127]，普通用户取值区间[1,24]
			///@param save_file_path （必须输入）存贮订阅信息文件的目录，请设定一个真实存在的有可写权限的路径
			///@param log_level 日志输出级别
			///@return 创建出的UserApi
			///@remark 只能创建一次，如果一个账户需要在多个客户端登录，请使用不同的client_id，系统允许一个账户同时登录多个客户端，但是对于同一账户，相同的client_id只能保持一个session连接，后面的登录在前一个session存续期间，无法连接。系统不支持过夜，请确保每天开盘前重新启动
			static TraderApi *CreateTraderApi(uint8_t client_id, const char *save_file_path, XTP_LOG_LEVEL log_level = XTP_LOG_LEVEL_DEBUG);

			///删除接口对象本身
			///@remark 不再使用本接口对象时,调用该函数删除接口对象
			virtual void Release() = 0;

			///获取当前交易日
			///@return 获取到的交易日
			///@remark 只有登录成功后,才能得到正确的交易日
			virtual const char *GetTradingDay() = 0;

			///注册回调接口
			///@param spi 派生自回调接口类的实例，请在登录之前设定
			virtual void RegisterSpi(TraderSpi *spi) = 0;

			///获取API的系统错误
			///@return 返回的错误信息，可以在Login、InsertOrder、CancelOrder返回值为0时调用，获取失败的原因
			///@remark 可以在调用api接口失败时调用，例如login失败时
			virtual XTPRI *GetApiLastError() = 0;

			///获取API的发行版本号
			///@return 返回api发行版本号
			virtual const char* GetApiVersion() = 0;

			///通过报单在xtp系统中的ID获取下单的客户端id
			///@return 返回客户端id，可以用此方法过滤自己下的订单
			///@param order_xtp_id 报单在xtp系统中的ID
			///@remark 由于系统允许同一用户在不同客户端上登录操作，每个客户端通过不同的client_id进行区分
			virtual uint8_t GetClientIDByXTPID(uint64_t order_xtp_id) = 0;

			///通过报单在xtp系统中的ID获取相关资金账户名
			///@return 返回资金账户名
			///@param order_xtp_id 报单在xtp系统中的ID
			///@remark 只有资金账户登录成功后,才能得到正确的信息
			virtual const char* GetAccountByXTPID(uint64_t order_xtp_id) = 0;

			///订阅公共流。
			///@param resume_type 公共流（订单响应、成交回报）重传方式  
			///        XTP_TERT_RESTART:从本交易日开始重传
			///        XTP_TERT_RESUME:(保留字段，此方式暂未支持)从上次收到的续传
			///        XTP_TERT_QUICK:只传送登录后公共流的内容
			///@remark 该方法要在Login方法前调用。若不调用则不会收到公共流的数据。注意在用户断线后，如果不登出就login()，公共流订阅方式不会起作用。用户只会收到断线后的所有消息。如果先logout()再login()，那么公共流订阅方式会起作用，用户收到的数据会根据用户的选择方式而定。
			virtual void SubscribePublicTopic(XTP_TE_RESUME_TYPE resume_type) = 0;

			///设置软件开发版本号
			///@param version 用户开发软件版本号，非api发行版本号，长度不超过15位，以'\0'结尾
			///@remark 此函数必须在Login之前调用，标识的是客户端版本号，而不是API的版本号，由用户自定义
			virtual void SetSoftwareVersion(const char* version) = 0;

			///设置软件开发Key
			///@param key 用户开发软件Key，用户申请开户时给予，以'\0'结尾
			///@remark 此函数必须在Login之前调用
			virtual void SetSoftwareKey(const char* key) = 0;

			///设置心跳检测时间间隔，单位为秒
			///@param interval 心跳检测时间间隔，单位为秒
			///@remark 此函数必须在Login之前调用
			virtual void SetHeartBeatInterval(uint32_t interval) = 0;

			///用户登录请求
			///@return session_id表明此资金账号登录是否成功，“0”表示登录失败，可以调用GetApiLastError()来获取错误代码，非“0”表示登录成功，此时需要记录下这个返回值session_id，与登录的资金账户对应
			///@param ip 服务器地址，类似“127.0.0.1”
			///@param port 服务器端口号
			///@param user 登录用户名
			///@param password 登录密码
			///@param sock_type “1”代表TCP，“2”代表UDP，目前暂时只支持TCP
			///@param local_ip 本地网卡地址，类似“127.0.0.1”
			///@remark 此函数为同步阻塞式，不需要异步等待登录成功，当函数返回即可进行后续操作，此api可支持多个账户连接，但是同一个账户同一个client_id只能有一个session连接，后面的登录在前一个session存续期间，无法连接
			virtual uint64_t Login(const char* ip, int port, const char* user, const char* password, XTP_PROTOCOL_TYPE sock_type, const char* local_ip = NULL) = 0;


			///登出请求
			///@return 登出是否成功，“0”表示登出成功，“-1”表示登出失败
			///@param session_id 资金账户对应的session_id,登录时得到
			///@remark 此函数为同步阻塞式，不需要异步等待登出，当函数返回即可进行后续操作，不允许在回调线程调用。
			virtual int Logout(uint64_t session_id) = 0;

// 			///服务器是否重启过
// 			///@return “true”表示重启过，“false”表示没有重启过
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@remark 此函数必须在Login之后调用
// 			virtual bool IsServerRestart(uint64_t session_id) = 0;
// 
// 			///修改已登录用户的硬件信息，仅限授权系统使用
// 			///@return 发送消息是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param info 需要修改成的用户硬件信息
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@remark 此函数必须在Login之后调用，且仅限授权系统使用，一般客户无需使用
// 			virtual int ModifyUserTerminalInfo(const XTPUserTerminalInfoReq* info, uint64_t session_id) = 0;

			///查询用户在本节点上的可交易市场类型
			///@return 按位来看，从低位开始数，第0位表示沪市，即如果(trade_location&0x01) == 0x01，代表可交易沪市，第1位表示深市，即如果(trade_location&0x02) == 0x02，表示可交易深市，如果第0位和第1位均是1，即(trade_location&(0x01|0x02)) == 0x03，就表示可交易沪深2个市场
			///@param session_id 资金账户对应的session_id,登录时得到
			///@remark 此函数必须在Login之后调用，为同步函数
			virtual uint32_t GetAccountTradeMarket(uint64_t session_id) = 0;

			///为用户获取一个新的订单XTPID，用于报单
			///@return 生成的订单XTPID，非“0”表示获取成功，“0”表示获取失败，此时用户可以调用GetApiLastError()来获取错误代码
			///@param session_id 资金账户对应的session_id,登录时得到
			///@remark 此函数必须在Login之后调用，通过这个函数获取的order_xtp_id仅用于对应的用户报单，如果设置错误，将会导致下单失败
			virtual uint64_t GetANewOrderXTPID(uint64_t session_id) = 0;

			///获取用户分页查询允许的最大查询数量
			///@return 分页查询允许的最大查询数量req_count，非“0”表示获取成功，“0”表示获取失败，此时用户可以调用GetApiLastError()来获取错误代码
			///@param session_id 资金账户对应的session_id,登录时得到
			///@remark 此函数必须在Login之后调用，通过这个函数获取的req_count可用于用户进行分页查询请求的填写，如果填写错误，将会导致分页查询接口调用失败
			virtual int64_t GetMaxReqNumOfPagedQuery(uint64_t session_id) = 0;

			///报单录入请求
			///@return 报单在XTP系统中的ID,如果为‘0’表示报单发送失败，此时用户可以调用GetApiLastError()来获取错误代码，非“0”表示报单发送成功，用户需要记录下返回的order_xtp_id，它保证一个交易日内唯一，不同的交易日不保证唯一性
			///@param order 报单录入信息，其中order.order_client_id字段是用户自定义字段，用户输入什么值，订单响应OnOrderEvent()返回时就会带回什么值，类似于备注，方便用户自己定位订单。当然，如果你什么都不填，也是可以的。order.order_xtp_id字段无需用户填写，order.ticker必须不带空格，以'\0'结尾
			///@param session_id 资金账户对应的session_id,登录时得到
			///@remark 交易所接收订单后，会在报单响应函数OnOrderEvent()中返回报单未成交的状态，之后所有的订单状态改变（除了部成状态）都会通过报单响应函数返回
			virtual uint64_t InsertOrder(XTPOrderInsertInfo *order, uint64_t session_id) = 0;

			///已经提前设置order_xtp_id的报单录入请求，与GetANewOrderXTPID()配合使用
			///@return 报单在XTP系统中的ID,如果为‘0’表示报单发送失败，此时用户可以调用GetApiLastError()来获取错误代码，非“0”表示报单发送成功，此时等同与传入的order_xtp_id
			///@param order 报单录入信息，其中order.order_client_id字段是用户自定义字段，用户输入什么值，订单响应OnOrderEvent()返回时就会带回什么值，类似于备注，方便用户自己定位订单，也可以什么都不填。order.order_xtp_id字段必须是通过GetANewOrderXTPID()获得的值，order.ticker必须不带空格，以'\0'结尾
			///@param session_id 资金账户对应的session_id,登录时得到
			///@remark 使用设置好的order_xtp_id（通过GetANewOrderXTPID()获得）进行报单，注意此处如果order_xtp_id设置不对，将导致报单失败。交易所接收订单后，会在报单响应函数OnOrderEvent()中返回报单未成交的状态，之后所有的订单状态改变（除了部成状态）都会通过报单响应函数返回
			virtual uint64_t InsertOrderExtra(XTPOrderInsertInfo *order, uint64_t session_id) = 0;

			///报单操作请求
			///@return 撤单在XTP系统中的ID,如果为‘0’表示撤单发送失败，此时用户可以调用GetApiLastError()来获取错误代码，非“0”表示撤单发送成功，用户需要记录下返回的order_cancel_xtp_id，它保证一个交易日内唯一，不同的交易日不保证唯一性
			///@param order_xtp_id 需要撤销的委托单在XTP系统中的ID
			///@param session_id 资金账户对应的session_id,登录时得到
			///@remark 如果撤单成功，会在报单响应函数OnOrderEvent()里返回原单部撤或者全撤的消息，如果不成功，会在OnCancelOrderError()响应函数中返回错误原因
			virtual uint64_t CancelOrder(const uint64_t order_xtp_id, uint64_t session_id) = 0;

			///根据报单ID请求查询报单
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param order_xtp_id 需要查询的报单在xtp系统中的ID，即InsertOrder()成功时返回的order_xtp_id
			///@param session_id 资金账户对应的session_id，登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			///@remark 该方法不受查询服务是否可用影响
			virtual int QueryOrderByXTPID(const uint64_t order_xtp_id, uint64_t session_id, int request_id) = 0;

			///请求查询报单
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param query_param 需要查询的订单相关筛选条件，其中合约代码可以为空，则默认所有存在的合约代码，如果不为空，请不带空格，并以'\0'结尾，其中起始时间格式为YYYYMMDDHHMMSSsss，为0则默认当前交易日0点，结束时间格式为YYYYMMDDHHMMSSsss，为0则默认当前时间
			///@param session_id 资金账户对应的session_id，登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			///@remark 该方法支持分时段查询，如果股票代码为空，则默认查询时间段内的所有报单，否则查询时间段内所有跟股票代码相关的报单，此函数查询出的结果可能对应多个查询结果响应。此函数不建议轮询使用，当报单量过多时，容易造成用户线路拥堵，导致api断线
			virtual int QueryOrders(const XTPQueryOrderReq *query_param, uint64_t session_id, int request_id) = 0;

			///请求查询未完结报单
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param session_id 资金账户对应的session_id，登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			virtual int QueryUnfinishedOrders(uint64_t session_id, int request_id) = 0;

			///分页请求查询报单
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param query_param 需要分页查询订单的条件，如果第一次查询，那么query_param.reference填0
			///@param session_id 资金账户对应的session_id，登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			///@remark 该方法支持分页查询，注意用户需要记录下最后一笔查询结果的reference以便用户下次查询使用
			virtual int QueryOrdersByPage(const XTPQueryOrderByPageReq *query_param, uint64_t session_id, int request_id) = 0;

// 			///根据报单ID请求查询报单
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param order_xtp_id 需要查询的报单在xtp系统中的ID，即InsertOrder()成功时返回的order_xtp_id
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryOrderByXTPIDEx(const uint64_t order_xtp_id, uint64_t session_id, int request_id) = 0;

// 			///请求查询报单
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要查询的订单相关筛选条件，其中合约代码可以为空，则默认所有存在的合约代码，如果不为空，请不带空格，并以'\0'结尾，其中起始时间格式为YYYYMMDDHHMMSSsss，为0则默认当前交易日0点，结束时间格式为YYYYMMDDHHMMSSsss，为0则默认当前时间
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 该方法支持分时段查询，如果股票代码为空，则默认查询时间段内的所有报单，否则查询时间段内所有跟股票代码相关的报单，此函数查询出的结果可能对应多个查询结果响应。此函数不建议轮询使用，当报单量过多时，容易造成用户线路拥堵，导致api断线
// 			virtual int QueryOrdersEx(const XTPQueryOrderReq *query_param, uint64_t session_id, int request_id) = 0;

// 			///请求查询未完结报单
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryUnfinishedOrdersEx(uint64_t session_id, int request_id) = 0;

// 			///分页请求查询报单-新版本接口
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要分页查询订单的条件，如果第一次查询，那么query_param.reference填0
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 该方法支持分页查询，注意用户需要记录下最后一笔查询结果的reference以便用户下次查询使用
// 			virtual int QueryOrdersByPageEx(const XTPQueryOrderByPageReq *query_param, uint64_t session_id, int request_id) = 0;

			///根据委托编号请求查询相关成交
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param order_xtp_id 需要查询的委托编号，即InsertOrder()成功时返回的order_xtp_id
			///@param session_id 资金账户对应的session_id，登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			///@remark 此函数查询出的结果可能对应多个查询结果响应
			virtual int QueryTradesByXTPID(const uint64_t order_xtp_id, uint64_t session_id, int request_id) = 0;

			///请求查询已成交
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param query_param 需要查询的成交回报筛选条件，其中合约代码可以为空，则默认所有存在的合约代码，如果不为空，请不带空格，并以'\0'结尾，其中起始时间格式为YYYYMMDDHHMMSSsss，为0则默认当前交易日0点，结束时间格式为YYYYMMDDHHMMSSsss，为0则默认当前时间
			///@param session_id 资金账户对应的session_id,登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			///@remark 该方法支持分时段查询，如果股票代码为空，则默认查询时间段内的所有成交回报，否则查询时间段内所有跟股票代码相关的成交回报，此函数查询出的结果可能对应多个查询结果响应。此函数不建议轮询使用，当报单量过多时，容易造成用户线路拥堵，导致api断线
			virtual int QueryTrades(XTPQueryTraderReq *query_param, uint64_t session_id, int request_id) = 0;

			///分页请求查询成交回报
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param query_param 需要分页查询成交回报的条件，如果第一次查询，那么reference填0
			///@param session_id 资金账户对应的session_id，登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			///@remark 该方法支持分页查询，注意用户需要记录下最后一笔查询结果的reference以便用户下次查询使用
			virtual int QueryTradesByPage(const XTPQueryTraderByPageReq *query_param, uint64_t session_id, int request_id) = 0;

			///按条件请求查询投资者指定持仓
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param ticker 需要查询持仓的合约代码，可以为NULL，表示查询沪深全市场主股卡持仓，如果不为NULL，请不带空格，并以'\0'结尾，注意需与market匹配，不匹配的话，查询不到所需的持仓
			///@param market 需要查询持仓的合约所在市场，仅在合约代码不为NULL的时候，才会使用。使用时，market必须指定。需要查单市场持仓，请使用QueryAllPosition()
			///@param session_id 资金账户对应的session_id,登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			///@remark 该方法如果用户提供了合约代码，则会查询此合约的主股卡持仓信息（注意请指定market，不指定查不到所需的持仓,此时不受查询服务是否可用影响），如果合约代码为空，则默认查询沪深市场的主股卡持仓信息,类似于使用QueryAllPosition()。
			virtual int QueryPosition(const char *ticker, uint64_t session_id, int request_id, XTP_MARKET_TYPE market) = 0;

			///按条件请求查询投资者持仓
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param query_param 需要查询持仓的条件，可以为NULL，表示查询沪深全市场主股卡持仓，如果不为NULL，会优先看股卡信息，如果提供了股卡，必须与market匹配；如果没有提供股卡信息，则默认查询market对应的主股卡持仓（注意market不可为0。当market不为0，ticker为空时，默认查询主股卡中market对应的持仓；当market不为0，ticker不为空时，默认查询主股卡中market里指定ticker的持仓）
			///@param session_id 资金账户对应的session_id,登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			///@remark 该方法如果用户没有提供股卡信息，则默认查主股卡的持仓，如果提供了股卡，必须与market匹配，否则查不到正确的持仓。此函数支持查指定合约代码的持仓。当查指定合约代码持仓时，不受查询服务是否可用影响。
			virtual int QueryAllPosition(const XTPQueryStkPositionReq* query_param, uint64_t session_id, int request_id) = 0;

			///请求查询用户的证券账户信息（股卡信息）
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param session_id 资金账户对应的session_id,登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			virtual int QuerySecurityAccount(uint64_t session_id, int request_id) = 0;

			///请求查询资产
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param session_id 资金账户对应的session_id,登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			///@remark 该方法不受查询服务是否可用影响
			virtual int QueryAsset(uint64_t session_id, int request_id) = 0;

// 			///请求查询分级基金
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要查询的分级基金筛选条件，其中母基金代码可以为空，则默认所有存在的母基金，如果不为空，请不带空格，并以'\0'结尾，其中交易市场不能为空
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 此函数查询出的结果可能对应多个查询结果响应
// 			virtual int QueryStructuredFund(XTPQueryStructuredFundInfoReq *query_param, uint64_t session_id, int request_id) = 0;

			///资金划拨请求
			///@return 资金划拨订单在XTP系统中的ID,如果为‘0’表示消息发送失败，此时用户可以调用GetApiLastError()来获取错误代码，非“0”表示消息发送成功，用户需要记录下返回的serial_id，它保证一个交易日内唯一，不同的交易日不保证唯一性
			///@param fund_transfer 资金划拨的请求信息
			///@param session_id 资金账户对应的session_id,登录时得到
			///@remark 此函数支持一号两中心节点之间的资金划拨，注意资金划拨的方向。此函数受资金划拨服务器是否可用影响。
			virtual uint64_t FundTransfer(XTPFundTransferReq *fund_transfer, uint64_t session_id) = 0;

			///请求查询指定资金划拨订单
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param serial_id 需要查询的资金划拨订单ID,不可以为0
			///@param session_id 资金账户对应的session_id,登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			///@remark 此函数不再支持全部查询，如果需要查询所有资金划拨订单，请使用分页查询接口QueryFundTransferByPage()查询。此函数受资金划拨服务器是否可用影响。
			virtual int QueryFundTransferByID(uint64_t serial_id, uint64_t session_id, int request_id) = 0;

			///分页请求查询资金划拨订单
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param query_param 需要分页查询订单的条件，如果第一次查询，那么query_param.reference填0
			///@param session_id 资金账户对应的session_id，登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			///@remark 该方法支持分页查询，注意用户需要记录下最后一笔查询结果的reference以便用户下次查询使用。此函数受资金划拨服务器是否可用影响。
			virtual int QueryFundTransferByPage(const XTPQueryFundTransferByPageReq *query_param, uint64_t session_id, int request_id) = 0;

			///请求查询其他节点可用资金
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param query_param 查询时需要提供的信息
			///@param session_id 资金账户对应的session_id,登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			///@remark 此函数受资金划拨服务器是否可用影响。
			virtual int QueryOtherServerFund(XTPFundQueryReq *query_param, uint64_t session_id, int request_id) = 0;

			///请求查询ETF清单文件
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param query_param 需要查询的ETF清单文件的筛选条件，其中合约代码可以为空，则默认所有存在的ETF合约代码，market字段也可以为初始值，则默认所有市场的ETF合约
			///@param session_id 资金账户对应的session_id,登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			virtual int QueryETF(XTPQueryETFBaseReq *query_param, uint64_t session_id, int request_id) = 0;

			///请求查询ETF股票篮
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param query_param 需要查询股票篮的的ETF合约，其中合约代码不可以为空，market字段也必须指定
			///@param session_id 资金账户对应的session_id,登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			virtual int QueryETFTickerBasket(XTPQueryETFComponentReq *query_param, uint64_t session_id, int request_id) = 0;

			///请求查询今日新股申购信息列表
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param session_id 资金账户对应的session_id,登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			virtual int QueryIPOInfoList(uint64_t session_id, int request_id) = 0;

			///请求查询用户新股申购额度信息
			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param session_id 资金账户对应的session_id,登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			virtual int QueryIPOQuotaInfo(uint64_t session_id, int request_id) = 0;

			///请求查询今日可转债申购信息列表
	        ///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
	        ///@param session_id 资金账户对应的session_id,登录时得到
	        ///@param request_id 用于用户定位查询响应的ID，由用户自定义
	        virtual int QueryBondIPOInfoList(uint64_t session_id, int request_id) = 0;

			///请求查询可转债转股的基本信息
			///@return 查询是否发送成功，“0”表示发送成功，非“0”表示发送出错，此时用户可以调用GetApiLastError()来获取错误代码
			///@param query_param 需要查询的可转债转股信息的筛选条件，可以为NULL（为NULL表示查询所有的可转债转股信息），此参数中合约代码可以为空字符串，如果为空字符串，则查询所有可转债转股信息，如果不为空字符串，请不带空格，并以'\0'结尾，且必须与market匹配
			///@param session_id 资金账户对应的session_id,登录时得到
			///@param request_id 用于用户定位查询响应的ID，由用户自定义
			virtual int QueryBondSwapStockInfo(XTPQueryBondSwapStockReq *query_param, uint64_t session_id, int request_id) = 0;

// 			///请求查询期权合约
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要查询的期权合约的筛选条件，可以为NULL（为NULL表示查询所有的期权合约）
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryOptionAuctionInfo(XTPQueryOptionAuctionInfoReq *query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///融资融券业务中现金直接还款请求
// 			///@return 现金直接还款订单在XTP系统中的ID,如果为‘0’表示消息发送失败，此时用户可以调用GetApiLastError()来获取错误代码，非“0”表示消息发送成功，用户需要记录下返回的xtp_id，它保证一个交易日内唯一，不同的交易日不保证唯一性
// 			///@param amount 现金还款的金额
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			virtual uint64_t CreditCashRepay(double amount, uint64_t session_id) = 0;
// 
// 			///融资融券业务中现金还指定负债合约息费请求
// 			///@return 现金还息订单在XTP系统中的ID,如果为‘0’表示消息发送失败，此时用户可以调用GetApiLastError()来获取错误代码，非“0”表示消息发送成功，用户需要记录下返回的xtp_id，它保证一个交易日内唯一，不同的交易日不保证唯一性
// 			///@param debt_id 指定的负债合约编号
// 			///@param amount 现金还息的金额
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			virtual uint64_t CreditCashRepayDebtInterestFee(const char* debt_id, double amount, uint64_t session_id) = 0;
// 
// 			///融资融券业务中卖券还指定负债合约息费请求
// 			///@return 卖券还息订单在XTP系统中的ID,如果为‘0’表示消息发送失败，此时用户可以调用GetApiLastError()来获取错误代码，非“0”表示消息发送成功，用户需要记录下返回的xtp_id，它保证一个交易日内唯一，不同的交易日不保证唯一性
// 			///@param order 卖券的报单录入信息，其中order.order_client_id字段是用户自定义字段，用户输入什么值，订单响应OnOrderEvent()返回时就会带回什么值，类似于备注，方便用户自己定位订单。当然，如果你什么都不填，也是可以的。order.order_xtp_id字段无需用户填写，order.ticker必须不带空格，以'\0'结尾
// 			///@param debt_id 指定的负债合约编号
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			virtual uint64_t CreditSellStockRepayDebtInterestFee(XTPOrderInsertInfo* order, const char* debt_id, uint64_t session_id) = 0;
// 
// 			///请求查询融资融券业务中的现金直接还款报单
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryCreditCashRepayInfo(uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询信用账户特有信息，除资金账户以外的信息
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryCreditFundInfo(uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询信用账户负债合约信息
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryCreditDebtInfo(uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询指定证券负债未还信息
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要查询的指定证券，筛选条件中ticker可以全填0，如果不为0，请不带空格，并以'\0'结尾
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryCreditTickerDebtInfo(XTPClientQueryCrdDebtStockReq *query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询信用账户待还资金信息
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryCreditAssetDebtInfo(uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询信用账户可融券头寸信息
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要查询的证券，筛选条件中ticker可以全填0，如果不为0，请不带空格，并以'\0'结尾
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryCreditTickerAssignInfo(XTPClientQueryCrdPositionStockReq *query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///融资融券业务中请求查询指定证券的余券
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要查询的余券信息，不可以为空，需要明确指定
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 该方法中用户必须提供了证券代码和所在市场
// 			virtual int QueryCreditExcessStock(XTPClientQueryCrdSurplusStkReqInfo *query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///融资融券业务中请求查询余券
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要查询的余券信息。若填入市场和股票代码，返回单支股票信息；若市场代码为空，股票代码非空，是无效查询，会在SPI中返回错误；若市场和股票代码均为空，返回全市场信息；若市场代码非空，股票代码为空，返回单市场信息。
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryMulCreditExcessStock(XTPClientQueryCrdSurplusStkReqInfo *query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///融资融券业务中请求负债合约展期
// 			///@return 负债合约展期订单在XTP系统中的ID,如果为‘0’表示消息发送失败，此时用户可以调用GetApiLastError()来获取错误代码，非“0”表示消息发送成功，用户需要记录下返回的xtp_id，它保证一个交易日内唯一，不同的交易日不保证唯一性
// 			///@param debt_extend 负债合约展期的请求信息
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			virtual uint64_t CreditExtendDebtDate(XTPCreditDebtExtendReq *debt_extend, uint64_t session_id) = 0;
// 
// 			///融资融券业务中请求查询负债合约展期
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param xtp_id 需要查询的负债合约展期订单筛选条件，xtp_id可以为0，则默认所有负债合约展期订单，如果不为0，则请求特定的负债合约展期订单
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryCreditExtendDebtDateOrders(uint64_t xtp_id, uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询融资融券业务中账戶的附加信息
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryCreditFundExtraInfo(uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询融资融券业务中账戶指定证券的附加信息
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要指定的证券，筛选条件中ticker可以全填0，如果不为0，请不带空格，并以'\0'结尾
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryCreditPositionExtraInfo(XTPClientQueryCrdPositionStockReq *query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///期权组合策略报单录入请求
// 			///@return 报单在XTP系统中的ID,如果为‘0’表示报单发送失败，此时用户可以调用GetApiLastError()来获取错误代码，非“0”表示报单发送成功，用户需要记录下返回的order_xtp_id，它保证一个交易日内唯一，不同的交易日不保证唯一性
// 			///@param order 报单录入信息，其中order.order_client_id字段是用户自定义字段，用户输入什么值，订单响应OnOptionCombinedOrderEvent()返回时就会带回什么值，类似于备注，方便用户自己定位订单。当然，如果你什么都不填，也是可以的。order.order_xtp_id字段无需用户填写，order.ticker必须不带空格，以'\0'结尾
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@remark 交易所接收订单后，会在报单响应函数OnOptionCombinedOrderEvent()中返回报单未成交的状态，之后所有的订单状态改变（除了部成状态）都会通过报单响应函数返回
// 			virtual uint64_t InsertOptionCombinedOrder(XTPOptCombOrderInsertInfo *order, uint64_t session_id) = 0;
// 
// 			///已经提前设置order_xtp_id的期权组合策略报单录入请求，与GetANewOrderXTPID()配合使用
// 			///@return 报单在XTP系统中的ID,如果为‘0’表示报单发送失败，此时用户可以调用GetApiLastError()来获取错误代码，非“0”表示报单发送成功，此时等同与传入的order_xtp_id
// 			///@param order 报单录入信息，其中order.order_client_id字段是用户自定义字段，用户输入什么值，订单响应OnOrderEvent()返回时就会带回什么值，类似于备注，方便用户自己定位订单，也可以什么都不填。order.order_xtp_id字段必须是通过GetANewOrderXTPID()获得的值，order.ticker必须不带空格，以'\0'结尾
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@remark 使用设置好的order_xtp_id（通过GetANewOrderXTPID()获得）进行报单，注意此处如果order_xtp_id设置不对，将导致报单失败。交易所接收订单后，会在报单响应函数OnOptionCombinedOrderEvent()中返回报单未成交的状态，之后所有的订单状态改变（除了部成状态）都会通过报单响应函数返回
// 			virtual uint64_t InsertOptionCombinedOrderExtra(XTPOptCombOrderInsertInfo *order, uint64_t session_id) = 0;
// 
// 			///期权组合策略报单撤单请求
// 			///@return 撤单在XTP系统中的ID,如果为‘0’表示撤单发送失败，此时用户可以调用GetApiLastError()来获取错误代码，非“0”表示撤单发送成功，用户需要记录下返回的order_cancel_xtp_id，它保证一个交易日内唯一，不同的交易日不保证唯一性
// 			///@param order_xtp_id 需要撤销的期权组合策略委托单在XTP系统中的ID
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@remark 如果撤单成功，会在报单响应函数OnOptionCombinedOrderEvent()里返回原单部撤或者全撤的消息，如果不成功，会在OnCancelOrderError()响应函数中返回错误原因
// 			virtual uint64_t CancelOptionCombinedOrder(const uint64_t order_xtp_id, uint64_t session_id) = 0;
// 
// 			///请求查询期权组合策略未完结报单-旧版本接口
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryOptionCombinedUnfinishedOrders(uint64_t session_id, int request_id) = 0;
// 
// 			///根据报单ID请求查询期权组合策略报单-旧版本接口
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param order_xtp_id 需要查询的报单在xtp系统中的ID，即InsertOrder()成功时返回的order_xtp_id
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryOptionCombinedOrderByXTPID(const uint64_t order_xtp_id, uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询期权组合策略报单-旧版本接口
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要查询的订单相关筛选条件，其中合约代码可以为空，则默认所有存在的合约代码，如果不为空，请不带空格，并以'\0'结尾，其中起始时间格式为YYYYMMDDHHMMSSsss，为0则默认当前交易日0点，结束时间格式为YYYYMMDDHHMMSSsss，为0则默认当前时间
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 该方法支持分时段查询，如果股票代码为空，则默认查询时间段内的所有报单，否则查询时间段内所有跟股票代码相关的报单，此函数查询出的结果可能对应多个查询结果响应。此函数不建议轮询使用，当报单量过多时，容易造成用户线路拥堵，导致api断线
// 			virtual int QueryOptionCombinedOrders(const XTPQueryOptCombOrderReq *query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///分页请求查询期权组合策略报单-旧版本接口
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要分页查询订单的条件，如果第一次查询，那么query_param.reference填0
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 该方法支持分页查询，注意用户需要记录下最后一笔查询结果的reference以便用户下次查询使用
// 			virtual int QueryOptionCombinedOrdersByPage(const XTPQueryOptCombOrderByPageReq *query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询期权组合策略未完结报单-新版本接口
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryOptionCombinedUnfinishedOrdersEx(uint64_t session_id, int request_id) = 0;
// 
// 			///根据报单ID请求查询期权组合策略报单-新版本接口
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param order_xtp_id 需要查询的报单在xtp系统中的ID，即InsertOrder()成功时返回的order_xtp_id
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			virtual int QueryOptionCombinedOrderByXTPIDEx(const uint64_t order_xtp_id, uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询期权组合策略报单-新版本接口
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要查询的订单相关筛选条件，其中合约代码可以为空，则默认所有存在的合约代码，如果不为空，请不带空格，并以'\0'结尾，其中起始时间格式为YYYYMMDDHHMMSSsss，为0则默认当前交易日0点，结束时间格式为YYYYMMDDHHMMSSsss，为0则默认当前时间
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 该方法支持分时段查询，如果股票代码为空，则默认查询时间段内的所有报单，否则查询时间段内所有跟股票代码相关的报单，此函数查询出的结果可能对应多个查询结果响应。此函数不建议轮询使用，当报单量过多时，容易造成用户线路拥堵，导致api断线
// 			virtual int QueryOptionCombinedOrdersEx(const XTPQueryOptCombOrderReq *query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///分页请求查询期权组合策略报单-新版本接口
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要分页查询订单的条件，如果第一次查询，那么query_param.reference填0
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 该方法支持分页查询，注意用户需要记录下最后一笔查询结果的reference以便用户下次查询使用
// 			virtual int QueryOptionCombinedOrdersByPageEx(const XTPQueryOptCombOrderByPageReq *query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///根据期权组合策略委托编号请求查询相关成交
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param order_xtp_id 需要查询的委托编号，即InsertOrder()成功时返回的order_xtp_id
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 此函数查询出的结果可能对应多个查询结果响应
// 			virtual int QueryOptionCombinedTradesByXTPID(const uint64_t order_xtp_id, uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询期权组合策略的成交回报
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要查询的成交回报筛选条件，其中合约代码可以为空，则默认所有存在的合约代码，如果不为空，请不带空格，并以'\0'结尾，其中起始时间格式为YYYYMMDDHHMMSSsss，为0则默认当前交易日0点，结束时间格式为YYYYMMDDHHMMSSsss，为0则默认当前时间
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 该方法支持分时段查询，如果股票代码为空，则默认查询时间段内的所有成交回报，否则查询时间段内所有跟股票代码相关的成交回报，此函数查询出的结果可能对应多个查询结果响应。此函数不建议轮询使用，当报单量过多时，容易造成用户线路拥堵，导致api断线
// 			virtual int QueryOptionCombinedTrades(const XTPQueryOptCombTraderReq *query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///分页请求查询期权组合策略成交回报
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要分页查询成交回报的条件，如果第一次查询，那么reference填0
// 			///@param session_id 资金账户对应的session_id，登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 该方法支持分页查询，注意用户需要记录下最后一笔查询结果的reference以便用户下次查询使用
// 			virtual int QueryOptionCombinedTradesByPage(const XTPQueryOptCombTraderByPageReq *query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询投资者期权组合策略持仓
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要查询持仓的筛选条件，其中组合策略代码可以初始化为空，表示查询所有，如果不为空，请不带空格，并以'\0'结尾，注意需与market匹配，不匹配的话，可能导致查询不到所需的持仓
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 该方法如果用户提供了合约代码，则会查询此合约的持仓信息（注意请指定market，如果market为0，可能会查询到2个市场的持仓，如果market为其他非有效值，则查询结果会返回找不到持仓），如果合约代码为空，则默认查询所有持仓信息。
// 			virtual int QueryOptionCombinedPosition(const XTPQueryOptCombPositionReq* query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询期权组合策略信息
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 该方法仅支持精确查询，不支持模糊查询
// 			virtual int QueryOptionCombinedStrategyInfo(uint64_t session_id, int request_id) = 0;
// 
// 			///请求查询期权行权合并头寸
// 			///@return 查询发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param query_param 需要查询的行权合并的筛选条件，其中market为0会默认查询全市场，成分合约代码可以初始化为空，如果不为空，请不带空格，并以'\0'结尾，注意所有填写的条件都会进行匹配
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 该方法可能对应多条响应消息
// 			virtual int QueryOptionCombinedExecPosition(const XTPQueryOptCombExecPosReq* query_param, uint64_t session_id, int request_id) = 0;
// 
// 			///用户登录algo服务器请求
// 			///@return 表明此资金账号登录是否成功，非“0”表示登录失败，可以调用GetApiLastError()来获取错误代码，“0”表示登录成功
// 			///@param ip algo服务器地址，类似“127.0.0.1”
// 			///@param port algo服务器端口号
// 			///@param user 登录用户名
// 			///@param password 登录密码
// 			///@param sock_type “1”代表TCP，“2”代表UDP，目前暂时只支持TCP
// 			///@param local_ip 本地网卡地址，类似“127.0.0.1”
// 			///@remark 此函数为同步阻塞式，不需要异步等待登录成功，当函数返回即可进行后续操作，此api只需调用一次，所有用户共用即可
// 			virtual int LoginALGO(const char* ip, int port, const char* user, const char* password, XTP_PROTOCOL_TYPE sock_type, const char* local_ip = NULL) = 0;
// 
// 			///algo业务中查询用户策略请求
// 			///@return 请求发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param strategy_type 需要查询的策略类型，可填0
// 			///@param client_strategy_id 需要查询的策略用户自定义id，可填0
// 			///@param xtp_strategy_id 需要查询的策略在xtp系统中的id，如果指定，就一定按指定查询，如果填0，则按其他筛选条件查询
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark xtp_strategy_id条件的优先级最高，只有当xtp_strategy_id为0时，其他条件才生效，此条请求可能对应多条回应消息
// 			virtual int QueryStrategy(uint32_t strategy_type, uint64_t client_strategy_id, uint64_t xtp_strategy_id, uint64_t session_id, int32_t request_id) = 0;
// 
// 			///用户请求使用algo服务器建立算法通道
// 			///@return 表明此资金账号建立算法通道请求消息发送是否成功，非“0”表示发送失败，可以调用GetApiLastError()来获取错误代码，“0”表示发送成功
// 			///@param oms_ip oms服务器地址，类似“127.0.0.1”，非algo服务器地址
// 			///@param oms_port oms服务器端口号，非algo服务器端口号
// 			///@param user 登录用户名
// 			///@param password 登录密码
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@remark 此函数为异步方式，一个用户只能拥有一个算法通道，如果之前已经建立，则无需重复建立，在使用算法前，请先建立算法通道
// 			virtual int ALGOUserEstablishChannel(const char* oms_ip, int oms_port, const char* user, const char* password, uint64_t session_id) = 0;
// 
// 			///algo业务中用户报算法单请求
// 			///@return 算法报单请求发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param strategy_type 需要创建的策略类型
// 			///@param client_strategy_id 用户自定义id，帮助用户定位
// 			///@param strategy_param 策略参数
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@remark 仅能在用户建立算法通道后使用，算法单的异步通知
// 			virtual int InsertAlgoOrder(uint32_t strategy_type, uint64_t client_strategy_id, char* strategy_param, uint64_t session_id) = 0;
// 
// 			///algo业务中用户撤销算法单请求
// 			///@return 请求发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param cancel_flag 是否需要算法去处理已下的算法子单标志，true-交给算法自行处理，包括撤单、平仓等，算法处理完成后会通知客户；false-立即停止算法母单的执行，此时算法平台会对已下的子单做撤单操作，其余的平仓等操作需要客户自己处理
// 			///@param xtp_strategy_id 需要撤销的算法单在xtp algobus系统中的id
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@remark 仅能在用户建立算法通道后调用
// 			virtual int CancelAlgoOrder(bool cancel_flag, uint64_t xtp_strategy_id, uint64_t session_id) = 0;
// 
// 			///获取算法单的母单ID
// 			///@return 返回算法单的母单ID，如果返回为0表示不是算法单
// 			///@param order_xtp_id 算法单对应的xtp id
// 			///@param order_client_id 算法单对应的自定义ID，不可随意填写
// 			///@remark 返回为0表示，不是算法单，如果传入的参数不对的话，可能会得不到正确结果，此函数调用不依赖于是否登录
// 			virtual uint64_t GetAlgorithmIDByOrder(uint64_t order_xtp_id, uint32_t order_client_id) = 0;
// 
// 			///algo业务中请求推荐算法
// 			///@return 请求发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param basket_flag 是否将满足条件的推荐结果打包成母单篮的标志，true-打包
// 			///@param basket_param 需要算法推荐的证券列表，为json字串，具体格式参考说明文档或咨询运营人员
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@param request_id 用于用户定位查询响应的ID，由用户自定义
// 			///@remark 此条请求可能对应多条回应消息，此功能上线时间视服务器后台支持情况而定，具体以运营通知时间为准
// 			virtual int StrategyRecommendation(bool basket_flag, char* basket_param, uint64_t session_id, int32_t request_id) = 0;
// 
// 			///algo业务中修改已有的算法单
// 			///@return 算法单修改请求发送是否成功，“0”表示成功，非“0”表示出错，此时用户可以调用GetApiLastError()来获取错误代码
// 			///@param xtp_strategy_id xtp算法单策略ID
// 			///@param strategy_param 修改后的策略参数
// 			///@param session_id 资金账户对应的session_id,登录时得到
// 			///@remark 仅能在用户建立算法通道后使用，此功能上线时间视服务器后台支持情况而定，具体以运营通知时间为准
// 			virtual int ModifyAlgoOrder(uint64_t xtp_strategy_id, char* strategy_param, uint64_t session_id) = 0;

		protected:
			~TraderApi() {};
		};

			}
}

#ifndef WINDOWS
#if __GNUC__ >= 4
#pragma GCC visibility pop
#endif
#endif


#endif
